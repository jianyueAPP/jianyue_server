/**  
* @title: ArticleStatus.java
* @package model
* @description: TODO
* @author Hughe  1044829783@qq.com  
* @date 2017年11月11日 下午11:00:56
* @version V1.0  
*/ 
package model;

import java.util.List;
import java.util.Map;

public enum  ArticleStatus {
   Science
}

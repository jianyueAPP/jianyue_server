/**  
* @title: ArticleDao.java
* @package dao
* @description: TODO
* @author Hughe  1044829783@qq.com  
* @date 2017年11月15日 下午7:37:36
* @version V1.0  
*/ 
package dao;

import java.util.List;

import basic.BasicService;
import model.Article;
import model.Pager;

public class ArticleDao extends BasicService implements IArticleDao {

    @Override
    public void addArticle(Article article) {
	// TODO Auto-generated method stub

    }

    @Override
    public void deleteArticle(Article article) {
	// TODO Auto-generated method stub

    }

    @Override
    public void updateArticle(Article article) {
	// TODO Auto-generated method stub

    }


    @Override
    public  List<Article> listArticle() {
	// TODO Auto-generated method stub
	return null;
    }

    @Override
    public List<Article> searchArticle(String condition) {
	// TODO Auto-generated method stub
	return null;
    }

}

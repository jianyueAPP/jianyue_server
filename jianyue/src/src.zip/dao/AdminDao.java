/**  
* @title: AdminDao.java
* @package dao
* @description: TODO
* @author Hughe  1044829783@qq.com  
* @date 2017年11月15日 下午7:26:44
* @version V1.0  
*/ 
package dao;

import basic.BasicService;
import model.Admin;

public class AdminDao extends BasicService implements IAdminDao{

    @Override
    public boolean isAdmin(Admin admin) {
	// TODO Auto-generated method stub
	return false;
    }

    @Override
    public Admin load(String adminname, String password) {
	// TODO Auto-generated method stub
	return null;
    }

    @Override
    public void update(Admin admin, String password) {
	// TODO Auto-generated method stub
	
    }
    
}
